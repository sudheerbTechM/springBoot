package com.sai;

import static org.junit.Assert.assertTrue;

import java.util.Optional;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.sai.entities.Employee;
import com.sai.services.EmployeeService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootJpaAppApplicationTests {
	
	@Autowired
	EmployeeService employeeService;

	@Test
	public void testInsertEmpDetails_Success() {
		Employee emp = new Employee();
		emp.setName("john");
		emp.setDesg("manager");
		boolean status=employeeService.create(emp);
		assertTrue(status);
	}
	
	@Test
	@Ignore
	public void testFetchEmpDetailsByID_Success() {
		Optional<Employee> optional=employeeService.fetchByID(1);
		boolean status=false;
		if(optional.isPresent()) {
			status=true;
		}
		assertTrue(status);
	}

}
