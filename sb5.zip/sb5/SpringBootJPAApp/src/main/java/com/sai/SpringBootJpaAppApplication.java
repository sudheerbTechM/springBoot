package com.sai;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.sai.entities.Employee;
import com.sai.services.EmployeeService;

@SpringBootApplication
public class SpringBootJpaAppApplication {
	


	public static void main(String[] args) {
		ApplicationContext applicationContext=SpringApplication.run(SpringBootJpaAppApplication.class, args);
//	    EmployeeService employeeService = (EmployeeService) applicationContext.getBean("employeeService");
//		Employee emp = new Employee();
//	    emp.setName("emp1");
//	    emp.setDesg("desg1");
//	    boolean status=employeeService.create(emp);
//	    System.out.println("Employee created: "+status);
	   // employeeService.fetchAll();
	}

}
