package com.sai.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.entities.Employee;
import com.sai.repositories.EmployeeRepository;

@Service
public class EmployeeService {
     
   @Autowired
   EmployeeRepository employeeRepository;
   
   public boolean create(Employee emp) {
	   return employeeRepository.save(emp) != null;
   }
   
   public void deleteByID(int id) {
	    employeeRepository.deleteById(id);
   }
   
   public Optional<Employee> fetchByID(int id) {
	   return employeeRepository.findById(id);
   }
   
   public void fetchAll() {
	   Iterable<Employee> iterable=employeeRepository.findAll();
	   iterable.forEach(emp -> {
		   System.out.println(emp.getName()+", "+emp.getDesg());
	   });
   }
	
}
